# Logic Fit Digital Bookstore

Next.js storefront recreated from the supplied UI reference screenshots.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000.

## Deploy to Vercel
Import this folder/repository into Vercel. Framework preset: Next.js. Build command: `npm run build`.

## Included screens
- Home / landing page
- Bookstore catalogue
- Protocol preview grid (six sample page images)
- Reader sign-in / create-account modal
- My Library placeholder
- Cart UI
- Publisher admin portal UI

## Important
The supplied ZIP contained only project configuration and lockfiles; it did not contain the original `app/`, `src/`, or component source code. This is a rebuilt frontend based on the screenshots. Sign-in, checkout, library purchases, and admin authentication are UI demos; connect a database, payment provider, and authentication service before using them for real transactions.
