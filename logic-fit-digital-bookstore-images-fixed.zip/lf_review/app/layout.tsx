import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Logic Fit Digital Bookstore', description: 'Evidence-based digital books for better work, health and performance.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
